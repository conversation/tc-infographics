
// GLOBAL VARS

// GLOBAL CONTSTANTS

// ========================================================================= //
function expandButtonClick() {

        var scroll = $(window).scrollTop();
        
        //console.log("Analysis expand button");     
        var parentClickID = jQuery(this).parent().attr('id');
            
        //console.log("Parent Div ID: " + parentClickID);
        // show-hide primer
        $("#" + parentClickID + " .responseText").toggleClass('show');

        if($("#" + parentClickID + " .responseText").hasClass('show')==true)
        {
            //console.log("Has class show");
            // update instructions
            $("#" + parentClickID + " .expandSymbol").empty();
            $("#" + parentClickID + " .expandSymbol").append('-');

            $("#" + parentClickID + " .expandText").empty();
            $("#" + parentClickID + " .expandText").append('close');             
            
        } else {
            //console.log("No class show");
            // update instructions
            $("#" + parentClickID + " .expandSymbol").empty();
            $("#" + parentClickID + " .expandSymbol").append('+');

            $("#" + parentClickID + " .expandText").empty();
            $("#" + parentClickID + " .expandText").append('expand'); 
            
        }      
        e.preventDefault();    
}

// ========================================================================= //

function bottomButtonClick() {

        var parentContainer = jQuery(this).parent().parent().attr('id');
        //console.log("Parent Div ID: " + parentContainer);
        
        // show-hide primer
        $("#" + parentContainer + " .responseText").toggleClass('show');
        
                var scroll = $(window).scrollTop();

        if($("#" + parentContainer + " .responseText").hasClass('show')==true)
        {
            //console.log("Has class show");
            // update instructions
            $("#" + parentContainer + " .expandSymbol").empty();
            $("#" + parentContainer + " .expandSymbol").append('-');

            $("#" + parentContainer + " .expandText").empty();
            $("#" + parentContainer + " .expandText").append('close');             
            
        } else {
            //console.log("No class show");
            // update instructions
            $("#" + parentContainer + " .expandSymbol").empty();
            $("#" + parentContainer + " .expandSymbol").append('+');

            $("#" + parentContainer + " .expandText").empty();
            $("#" + parentContainer + " .expandText").append('expand'); 
            
        }       
        e.preventDefault();    
}
// ========================================================================= //

function getResponseClass(response){
    switch(response) {
        case 'Strongly agree':
            return 'stronglyAgree';
            break;
        case 'Agree':
            return 'agree';
            break;
        case 'Uncertain':
            return 'uncertain';
        case 'Disagree':
            return 'disagree';
        case 'No opinion':
            return 'noOpinion';
    }
}
// ========================================================================= //
function buildSurveyResults(){
    for (var economist in surveyResults) {
        if (surveyResults.hasOwnProperty(economist)) {
            console.log(surveyResults[economist]["Fullname"]);
            console.log(surveyResults[economist]["Response"]);
            
            var name = surveyResults[economist]["Fullname"];
            var response = surveyResults[economist]["Response"];
            var confidence = surveyResults[economist]["Confidence"];
            var comment = surveyResults[economist]["Comment"];
            
            var economistID = name.replace(" ", "");
            var responseClass = getResponseClass(response);
            
            console.log(economistID);
            $("#surveyResults").append("<div id='" + economistID + "'></div>")
            $("#" + economistID).append("<div class='responseButton " + responseClass + "'><img class='icon' src='images/MardiDungey.jpg'><div class='buttonItems'><span class='heading'>" + name + "</span><span class='response'>" + response + "</span><span class='expandButton expandSymbol'>+</span><span class='expandButton expandText'>expand</span></div></div><div class='responseText'>" + comment + "<div class='confidence'><ul><li><span class='label'>Confidence:</span><span class='value'>" + confidence + "</span></li></ul></div><div class='bottomCloseBtn'>&uarr; Close</div></div>");
        }
    }
}

// ========================================================================= //
// ========================================================================= //
// DOCUMENT READY FUNCTION 
jQuery(document).ready(function($) {

    // ********************* PRIMER EXPAND BUTTON CLICK *********************
    $(".responseButton").on('click', function(e)  {
        //expandButtonClick();
    });
        
    // ********************* PRIMER BOTTOM CLOSE CLICK *********************
    $(".bottomCloseBtn").on('click', function(e)  {
        //bottomButtonClick();        
    });
    
    // ********************* BUILD RESULTS *********************
    buildSurveyResults();
           
});